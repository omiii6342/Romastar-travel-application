import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StyleSheet, Text, View, TouchableOpacity, StatusBar, TextInput, ScrollView, Dimensions, Animated } from 'react-native';
import { ImageBackground } from 'expo-image';
import { Feather, FontAwesome5, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import BottomNav from '../components/BottomNav';

import { useAuth } from '../context/AuthContext';
import { useTrip } from '../context/TripContext';
import AnalyticsService from '../services/AnalyticsService';
import { useTheme } from '../context/ThemeContext';

const { width } = Dimensions.get('window');

const PARIS_IMG = 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=600&auto=format&fit=crop';
const ROME_IMG = 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?q=80&w=600&auto=format&fit=crop';
const SWISS_IMG = 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?q=80&w=600&auto=format&fit=crop';
const DUBAI_IMG = 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=600&auto=format&fit=crop';

export default function ExploreScreen({ navigation }) {
    const { isLoggedIn, hasSeenQuiz, markQuizSeen } = useAuth();
    const { activeTrip } = useTrip();
    const { isDarkMode, colors } = useTheme();

    // Premium slide-up animation
    const slideAnim = React.useRef(new Animated.Value(20)).current;
    const fadeAnim = React.useRef(new Animated.Value(0)).current;

    React.useEffect(() => {
        if (!isLoggedIn) {
            Animated.parallel([
                Animated.timing(slideAnim, {
                    toValue: 0,
                    duration: 800,
                    useNativeDriver: true,
                }),
                Animated.timing(fadeAnim, {
                    toValue: 1,
                    duration: 800,
                    useNativeDriver: true,
                })
            ]).start();
        }
    }, [isLoggedIn]);

    return (
        <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
            <StatusBar barStyle={isDarkMode ? "light-content" : "dark-content"} backgroundColor={colors.background} />
            <ScrollView
                contentContainerStyle={styles.scrollContainer}
                showsVerticalScrollIndicator={false}
            >

                {/* Top Header Row */}
                <View style={styles.topHeaderFlex}>
                    <View>
                        <Text style={[styles.brandTitle, { color: colors.text }]}>Roamster</Text>
                        <Text style={[styles.brandSubtitle, { color: colors.text }]}>Pack light, live loud.</Text>
                    </View>
                    <View style={styles.headerRightButtons}>
                        <TouchableOpacity
                            style={[styles.iconCircle, { backgroundColor: colors.card }]}
                            onPress={() => navigation.navigate('Camera')}
                        >
                            <Ionicons name="camera-outline" size={22} color={colors.text} />
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.iconCircle, { backgroundColor: colors.card }]}
                            onPress={() => navigation.navigate('Notifications')}
                        >
                            <Ionicons name="notifications-outline" size={22} color={colors.text} />
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Search Bar */}
                <View style={[styles.searchBarContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
                    <Feather name="search" size={20} color={colors.subtext} style={styles.searchIcon} />
                    <TextInput
                        style={[styles.searchInput, { color: colors.text }]}
                        placeholder="Where's your next photo op?"
                        placeholderTextColor={colors.subtext}
                        onSubmitEditing={(e) => {
                            navigation.navigate('AllPlaces', { searchQuery: e.nativeEvent.text });
                        }}
                    />
                </View>

                {/* Category Icons */}
                <View style={styles.categoriesContainer}>
                    <View style={styles.categoryItem}>
                        <TouchableOpacity
                            style={[styles.categoryIconCircle, { backgroundColor: colors.card, borderColor: colors.divider }]}
                            onPress={() => navigation.navigate('CityFood', { city: 'Paris' })}
                        >
                            <MaterialCommunityIcons name="silverware-fork-knife" size={24} color={colors.text} />
                        </TouchableOpacity>
                        <Text style={styles.categoryLabel}>FOOD</Text>
                    </View>
                    <View style={styles.categoryItem}>
                        <TouchableOpacity
                            style={[styles.categoryIconCircle, { backgroundColor: colors.card, borderColor: colors.divider }]}
                            onPress={() => navigation.navigate('Map', { city: 'Paris', location: 'Eiffel Tower, Paris' })}
                        >
                            <Ionicons name="map-outline" size={24} color={colors.text} />
                        </TouchableOpacity>
                        <Text style={styles.categoryLabel}>MAP</Text>
                    </View>
                    <View style={styles.categoryItem}>
                        <TouchableOpacity
                            style={[styles.categoryIconCircle, { backgroundColor: colors.card, borderColor: colors.divider }]}
                            onPress={() => navigation.navigate('Guide', { city: 'Paris' })}
                        >
                            <Ionicons name="document-text-outline" size={24} color={colors.text} />
                        </TouchableOpacity>
                        <Text style={styles.categoryLabel}>GUIDE</Text>
                    </View>
                    <View style={styles.categoryItem}>
                        <TouchableOpacity
                            style={[styles.categoryIconCircle, { backgroundColor: colors.card, borderColor: colors.divider }]}
                            onPress={() => navigation.navigate('Saved')}
                        >
                            <Ionicons name="heart-outline" size={24} color={colors.text} />
                        </TouchableOpacity>
                        <Text style={styles.categoryLabel}>FAVORITES</Text>
                    </View>
                </View>

                {/* Trending Section */}
                <View style={styles.sectionHeader}>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>Trending Hotspots</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('AllDestinations')}>
                        <Text style={[styles.seeAllText, { color: colors.text }]}>View All</Text>
                    </TouchableOpacity>
                </View>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.horizontalScroll}
                >
                    {/* Card 1: Switzerland */}
                    <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Switzerland')} style={styles.destinationCard}>
                        <ImageBackground 
                            source={{ uri: SWISS_IMG }} 
                            style={styles.cardImage} 
                            imageStyle={{ borderRadius: 24 }} 
                            transition={300}
                            placeholder="L6G*e[4n00~q00%M%MD%00xV-;_k"
                            contentFit="cover"
                        >
                            <View style={styles.cardOverlay}>
                                <View style={{ flex: 1 }} />
                                <View style={styles.cardBottomText}>
                                    <Text style={styles.cardCity}>Switzerland</Text>
                                    <Text style={styles.cardStats}>1.1k roamsters active</Text>
                                </View>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    {/* Card: Dubai */}
                    <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Dubai')} style={styles.destinationCard}>
                        <ImageBackground 
                            source={{ uri: DUBAI_IMG }} 
                            style={styles.cardImage} 
                            imageStyle={{ borderRadius: 24 }} 
                            transition={300}
                            placeholder="L6G*e[4n00~q00%M%MD%00xV-;_k"
                            contentFit="cover"
                        >
                            <View style={styles.cardOverlay}>
                                <View style={{ flex: 1 }} />
                                <View style={styles.cardBottomText}>
                                    <Text style={styles.cardCity}>Dubai</Text>
                                    <Text style={styles.cardStats}>2.3k roamsters active</Text>
                                </View>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    {/* Card 2: Paris */}
                    <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Paris')} style={styles.destinationCard}>
                        <ImageBackground 
                            source={{ uri: PARIS_IMG }} 
                            style={styles.cardImage} 
                            imageStyle={{ borderRadius: 24 }} 
                            transition={300}
                            placeholder="L6G*e[4n00~q00%M%MD%00xV-;_k"
                            contentFit="cover"
                        >
                            <View style={styles.cardOverlay}>
                                <View style={styles.pillContainer}>
                                    <Text style={styles.pillText}>INFLUENCER PICK</Text>
                                </View>
                                <View style={styles.cardBottomText}>
                                    <Text style={styles.cardCity}>Paris</Text>
                                    <Text style={styles.cardStats}>1.2k roamsters active</Text>
                                </View>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    {/* Card 3: Rome */}
                    <TouchableOpacity activeOpacity={0.9} onPress={() => navigation.navigate('Rome')} style={styles.destinationCard}>
                        <ImageBackground 
                            source={{ uri: ROME_IMG }} 
                            style={styles.cardImage} 
                            imageStyle={{ borderRadius: 24 }} 
                            transition={300}
                            placeholder="L6G*e[4n00~q00%M%MD%00xV-;_k"
                            contentFit="cover"
                        >
                            <View style={styles.cardOverlay}>
                                <View style={{ flex: 1 }} />
                                <View style={styles.cardBottomText}>
                                    <Text style={styles.cardCity}>Rome</Text>
                                    <Text style={styles.cardStats}>850 roamsters active</Text>
                                </View>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>
                </ScrollView>

                {/* Premium Unlock Banner */}
                {!isLoggedIn && (
                    <Animated.View style={{ 
                        opacity: fadeAnim, 
                        transform: [{ translateY: slideAnim }],
                        paddingHorizontal: 20,
                        marginTop: 25,
                        marginBottom: 30
                    }}>
                        <TouchableOpacity
                            style={styles.premiumBannerContainer}
                            activeOpacity={0.9}
                            onPress={() => navigation.navigate('Login')}
                        >
                            <View style={styles.bannerTextContent}>
                                <Text style={styles.premiumBannerTitle}>Unlock full access</Text>
                                <Text style={styles.premiumBannerDesc}>Login to unlock all places, food, clothes, and exclusive travel guides.</Text>
                                <View style={styles.premiumBannerButton}>
                                    <Text style={styles.premiumBannerButtonText}>Login to unlock</Text>
                                </View>
                            </View>
                            <View style={styles.bannerIconBox}>
                                <Ionicons name="lock-closed" size={70} color="rgba(255,255,255,0.08)" />
                            </View>
                        </TouchableOpacity>
                    </Animated.View>
                )}

                {/* Style Quiz Banner */}
                {isLoggedIn && !hasSeenQuiz && (
                    <View style={styles.bannerContainer}>
                        <TouchableOpacity 
                            style={{ position: 'absolute', top: 12, right: 15, zIndex: 10 }}
                            onPress={markQuizSeen}
                            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                        >
                            <Ionicons name="close" size={20} color="rgba(255,255,255,0.5)" />
                        </TouchableOpacity>
                        <View style={styles.bannerTextContent}>
                            <Text style={styles.bannerTitle}>Zero luggage,</Text>
                            <Text style={styles.bannerTitle}>total style.</Text>
                            <Text style={styles.bannerDesc}>Rent curated outfits based on your destination's vibe.</Text>
                            <TouchableOpacity 
                                style={styles.bannerButton} 
                                activeOpacity={0.8}
                                onPress={() => {
                                    markQuizSeen();
                                    navigation.navigate('FiltersPreferences');
                                }}
                            >
                                <Text style={styles.bannerButtonText}>Start Style Quiz</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.bannerIconBox}>
                            <MaterialCommunityIcons name="hanger" size={80} color="rgba(255,255,255,0.7)" style={{ transform: [{ rotate: '15deg' }] }} />
                        </View>
                    </View>
                )}

            </ScrollView>

            <BottomNav activeRoute="Explore" />

        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: '#FAFAF9',
    },
    scrollContainer: {
        paddingHorizontal: 20,
        paddingTop: 30,
        paddingBottom: 120, // Extra space for floating nav
    },
    // Header
    topHeaderFlex: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 25,
    },
    brandTitle: {
        fontSize: 32,
        fontWeight: '900',
        color: '#0F172A',
        letterSpacing: -0.5,
    },
    brandSubtitle: {
        fontSize: 16,
        color: '#000000',
        marginTop: 4,
        fontWeight: '500',
    },
    headerRightButtons: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconCircle: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: '#F8FAFC',
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 12,
    },
    // Categories
    categoriesContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 35,
        paddingHorizontal: 10,
    },
    categoryItem: {
        alignItems: 'center',
    },
    categoryIconCircle: {
        width: 65,
        height: 65,
        borderRadius: 32.5,
        backgroundColor: '#FFFFFF',
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 10,
        elevation: 3,
        borderWidth: 1,
        borderColor: '#F1F5F9',
    },
    categoryLabel: {
        fontSize: 10,
        fontWeight: '800',
        color: '#94A3B8',
        marginTop: 12,
        letterSpacing: 1,
    },

    // Search
    searchBarContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#E2E8F0',
        borderRadius: 24,
        paddingHorizontal: 15,
        height: 52,
        marginBottom: 30,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.03,
        shadowRadius: 5,
        elevation: 1,
    },
    searchIcon: {
        marginRight: 10,
    },
    searchInput: {
        flex: 1,
        fontSize: 15,
        color: '#1E293B',
    },

    // Trending Section
    sectionTitle: {
        fontSize: 18,
        fontWeight: '800',
        color: '#000000',
        marginBottom: 15,
    },
    horizontalScroll: {
        paddingBottom: 10,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    seeAllText: {
        fontSize: 13,
        fontWeight: '600',
        color: '#000000',
    },
    destinationCard: {
        width: width * 0.6,
        height: 320,
        marginRight: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
        elevation: 5,
        borderRadius: 24,
        backgroundColor: '#FFF',
    },
    cardImage: {
        width: '100%',
        height: '100%',
    },
    cardOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.2)', // Light tint
        borderRadius: 24,
        padding: 15,
        justifyContent: 'space-between',
    },
    pillContainer: {
        backgroundColor: 'white',
        alignSelf: 'flex-start',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
    },
    pillText: {
        fontSize: 10,
        fontWeight: '800',
        color: '#0F172A',
    },
    cardBottomText: {
        marginTop: 'auto',
    },
    cardCity: {
        color: 'white',
        fontSize: 28,
        fontWeight: '800',
    },
    cardStats: {
        color: 'rgba(255,255,255,0.9)',
        fontSize: 12,
        fontWeight: '500',
        marginTop: 4,
    },

    // Banners
    bannerContainer: {
        marginTop: 30,
        backgroundColor: '#7C3AED', // Purple for Quiz
        borderRadius: 24,
        padding: 24,
        flexDirection: 'row',
        alignItems: 'center',
        overflow: 'hidden',
        position: 'relative',
        shadowColor: '#7C3AED',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 15,
        elevation: 8,
    },
    bannerTextContent: {
        flex: 1,
        zIndex: 2,
    },
    bannerTitle: {
        color: 'white',
        fontSize: 22,
        fontWeight: '800',
        letterSpacing: -0.5,
    },
    bannerDesc: {
        color: 'rgba(255,255,255,0.85)',
        fontSize: 14,
        marginTop: 10,
        marginBottom: 20,
        lineHeight: 20,
        paddingRight: 20,
    },
    bannerButton: {
        backgroundColor: 'white',
        alignSelf: 'flex-start',
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 20,
    },
    bannerButtonText: {
        color: '#222222',
        fontWeight: '800',
        fontSize: 14,
    },
    premiumBannerContainer: {
        backgroundColor: '#0F172A',
        borderRadius: 24,
        padding: 24,
        flexDirection: 'row',
        alignItems: 'center',
        overflow: 'hidden',
        position: 'relative',
        shadowColor: '#000000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 15,
        elevation: 8,
    },
    premiumBannerTitle: {
        color: '#FFFFFF',
        fontSize: 22,
        fontWeight: '800',
        letterSpacing: -0.5,
    },
    premiumBannerDesc: {
        color: 'rgba(255, 255, 255, 0.7)',
        fontSize: 14,
        marginTop: 10,
        marginBottom: 20,
        lineHeight: 20,
        paddingRight: 20,
    },
    premiumBannerButton: {
        backgroundColor: '#FFFFFF',
        alignSelf: 'flex-start',
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 20,
    },
    premiumBannerButtonText: {
        color: '#0F172A',
        fontWeight: '800',
        fontSize: 14,
    },
    bannerIconBox: {
        position: 'absolute',
        right: -10,
        bottom: -15,
    },
    navText: {
        fontSize: 9,
        fontWeight: '700',
        color: '#94A3B8',
        marginTop: 4,
    },
    activeNavText: {
        color: '#222222',
        marginTop: 0,
    },
});
